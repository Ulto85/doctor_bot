

function myFunction() {
  var x = document.getElementById("inp").value;
  console.log(x);
  /*console.log(x)*/
  const req = new XMLHttpRequest();
  const url='https://doctorbot.robowolf.repl.co/doctorapi/'+x;
  /*console.log(url)*/
  
  req.onreadystatechange = function() {
    if (this.readyState == 4 && this.status == 200) {
       //The responseText property
       //returns a text string
        document.getElementById('answer').innerHTML= req.responseText;
       //Do some stuff
    }
};
req.open("GET", url, true);
req.send();
  
}
document.getElementById('demo').onclick = myFunction;

